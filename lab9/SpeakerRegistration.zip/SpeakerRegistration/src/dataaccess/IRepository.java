package dataaccess;
import domain.Speaker;


public interface IRepository {
	int saveSpeaker(Speaker speaker);
}
