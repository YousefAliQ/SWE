package bank;

public class CurrencyConverter {

	public double convertEurosToDollars(double amount){
		return 1.12*amount;
	}
}
