package bank;

public class Account {
	private double balance;
	private CurrencyConverter currencyConverter = new CurrencyConverter();

	public void deposit(double amount) {
		if (amount >= 0.0) {
			balance = balance + amount;
		}
	}

	public void withdraw(double amount) {
		if (amount >= 0.0) {
			balance = balance - amount;
		}
	}

	public void depositEuros(double amount) {
		if (amount >= 0.0) {
			double dollarAmount = currencyConverter.convertEurosToDollars(amount);
			deposit(dollarAmount);
		}
	}

	public void withdrawEuros(double amount) {
		if (amount >= 0.0) {
			double dollarAmount = currencyConverter.convertEurosToDollars(amount);
			withdraw(dollarAmount);
		}
	}

	public double getBalance() {
		return balance;
	}

}
